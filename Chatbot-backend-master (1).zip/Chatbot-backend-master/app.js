'use strict'

require('dotenv').config();

const express = require("express")
const cfenv = require("cfenv")
const cors = require('cors')
const mongoose = require('mongoose')

const app = express()
let appEnv = cfenv.getAppEnv()

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({
    extended: true
}));

//Import route files
const assistantdRoutes = require('./routes/assistantRoutes')
const authRoutes = require('./routes/authRoutes')

//Data parsers for the request body
app.use(express.json())

//Allowing CORS to FRONTEND reqs in another domain
app.use(cors())

//DB connection
mongoose.connect(process.env.MONGO_URL_CONNECTION)

//Define the route files here
app.use('/assistant', assistantdRoutes)
app.use('/auth', authRoutes)

//Starts the application server 
var port = process.env.PORT || 6005
app.listen(appEnv.port, function () {
    console.log("Server running at: http://localhost:" + appEnv.port);
});

module.exports = app;