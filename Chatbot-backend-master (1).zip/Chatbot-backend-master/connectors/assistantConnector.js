var AssistantV1 = require('watson-developer-cloud/assistant/v1');
var _ = require('lodash');

//Instantiating Assistant service
var assistant = new AssistantV1({
    version: '2018-07-27',
    username: process.env.ASSISTANT_USERNAME,
    password: process.env.ASSISTANT_PASSWORD,
    url: process.env.ASSISTANT_URL
});

/* ------------sendMessageToAssistant-----------------
Receives a string containing the user's input text 
and sends it to Watson Assistant service
------------------------------------------------------*/
async function sendMessageToAssistant(payload) {

    let workspace_id = JSON.parse(process.env.ASSISTANT_WORKSPACE_ID);

    let skill;
    if (_.get(payload, 'context.skill')) {
        skill = workspace_id[payload.context.skill];
        console.log(`DIN SENDING TO WORKSPACE ID: ${workspace_id[payload.context.skill]} , NAME: ${payload.context.skill}`);
    } else {
        skill = (payload.language === 'es-es') ? workspace_id[process.env.DEFAULT_SKILL_SPA] : workspace_id[process.env.DEFAULT_SKILL];
        console.log(`ES SENDING TO WORKSPACE ID: ${workspace_id[process.env.DEFAULT_SKILL_SPA]} , NAME: ${process.env.DEFAULT_SKILL_SPA}`);
        console.log(`ES SENDING TO WORKSPACE ID: ${workspace_id[process.env.DEFAULT_SKILL]} , NAME: ${process.env.DEFAULT_SKILL}`);
    }

    return new Promise((resolve, reject) => {
        assistant.message({
            workspace_id: (payload && payload.context && payload.context.skill) ? workspace_id[payload.context.skill] : skill,
            input: {
                text: payload.input ? payload.input : ""
            },
            context: payload.context ? payload.context : null,
            nodes_visited_details: true

        }, function(err, response) {
            if (err) {
                reject('Error: ' + err);
            } else {
                resolve(response);
            }
        });
    })
}

module.exports = {
    sendMessageToAssistant: sendMessageToAssistant
};