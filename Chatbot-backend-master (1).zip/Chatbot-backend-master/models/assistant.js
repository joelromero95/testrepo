const mongoose = require('mongoose');

var assistantSchema = new mongoose.Schema({
    conversationID: { type: String, required: true },
    email: { type: String, required: true },
    iterationCount: { type: Number, required: true },
    startedTime: { type: Date, required: true },
    conversation: { type: [], required: true },
    nodes: {
        visited: { type: [], required: true },
        count: { type: Number, required: true }
    }
});

module.exports = (schema) => mongoose.model(schema, assistantSchema, schema);