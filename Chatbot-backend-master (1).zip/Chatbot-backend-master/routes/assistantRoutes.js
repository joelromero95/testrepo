const assistantRoutes = require('express').Router();
const assistantController = require('../controllers/assistantController')
const mongoController = require('../controllers/mongoController')

assistantRoutes.post('/', async function(req, res, next) {
    try {
        let result = await assistantController.sendInputMessage(req.body)
            .then(response => {
                res.status(200).send({
                    'message': 'Conversation registered successfully!',
                    'data': response
                });
            })
            .catch(err => {
                res.status(500).send({
                    'message': 'Conversation not registered!' + err
                });
            });
    } catch (err) {
        res.status(500).send({
            'message': 'Conversation not registered!',
            'data': err
        });
    }
});

assistantRoutes.post('/feedback', async function(req, res, next) {
    try {
        const payload = req.body
        payload.schema = (payload.language === 'pt-br') ? process.env.ASSISTANT_SCHEMA : process.env.ASSISTANT_SCHEMA_SPA;
        let result = await mongoController.registerFeedback(payload)
            .then(response => {
                res.status(200).send({
                    'message': 'Conversation registered successfully!',
                    'data': response
                });
            })
            .catch(err => {
                res.status(500).send({
                    'message': 'Conversation not registered!' + err
                });
            });
    } catch (err) {
        res.status(500).send({
            'message': 'Conversation not registered!',
            'data': err
        });
    }
});

module.exports = assistantRoutes;