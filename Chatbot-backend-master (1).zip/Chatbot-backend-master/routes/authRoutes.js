const router = require('express').Router()
const saml2 = require('saml2-js');
const fs = require('fs');
const CryptoJS = require("crypto-js");

const sp_options = {
    entity_id: process.env.ENTITYID,
    certificate: fs.readFileSync('idp-signing.crt').toString(),
    assert_endpoint: process.env.ASSERT_ENDPOINT
};

const sp = new saml2.ServiceProvider(sp_options);

const idp_options = {
    sso_login_url: process.env.SSO_LOGIN,
    sso_logout_url: process.env.SSO_LOGOUT,
    certificates: [fs.readFileSync('idp-signing.crt').toString()]
};

const idp = new saml2.IdentityProvider(idp_options);

router.get("/", function (req, res) {
    res.type('application/xml');
    res.send(sp.create_metadata());
});

// Starting point for login
router.get("/login", function (req, res) {
    sp.create_login_request_url(idp, {}, function (err, login_url, request_id) {
        if (err != null) {
            console.log(err);
            return res.send(500);
        }
        res.status(200).send({ redirect: login_url });
    });
});

// Assert endpoint for when login completes
router.post("/assert", function (req, res) {

    const options = {
        request_body: req.body,
        allow_unencrypted_assertion: true
    };

    let params = {};

    sp.post_assert(idp, options, function (err, saml_response) {
        console.log(saml_response);
        if (err !== null) {
            console.log(err);

            params = {
                auth: false
            }

        } else {

            const email = saml_response.user.name_id;
            const session = saml_response.user.session_index;

            let username;
            if (saml_response.user && saml_response.user.jnjMSUsername) {
                username = saml_response.user.jnjMSUsername;
            }

            params = {
                auth: true,
                email: email,
                session: session,
                username: username
            }

        }

        const ciphertext = CryptoJS.AES.encrypt(JSON.stringify(params), 'abcd1234');
        res.redirect(`${process.env.SSO_REDIRECT}?params=${encodeURIComponent(ciphertext)}`);
    });
});

// Starting point for logout
router.get("/logout", function (req, res) {
    const options = {
        name_id: req.body.email,
        session_index: req.body.session
    };

    sp.create_logout_request_url(idp, options, function (err, logout_url) {
        if (err != null)
            return res.send(500);
        res.redirect(logout_url);
    });
});

module.exports = router
