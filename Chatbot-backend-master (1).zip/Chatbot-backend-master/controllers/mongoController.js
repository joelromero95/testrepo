const Assistant = require('../models/assistant');

/* ------------ registerNewConversation ------------------ 
Create a new assistant interaction document and register
on the database
------------------------------------------------------- */
async function registerNewConversation(payload) {
    try {

        let model = Assistant(payload.schema);
        let newAssistantInteraction = new model();

        newAssistantInteraction.conversationID = payload.assistant.context.conversation_id
        newAssistantInteraction.email = payload.email
        newAssistantInteraction.startedTime = payload.startedTime
        newAssistantInteraction.iterationCount = 0
        newAssistantInteraction.conversation = [{
            iteration: 0,
            intent: payload.assistant.intents,
            entity: payload.assistant.entities,
            input: payload.assistant.input.text,
            output: payload.assistant.output.text.join(' '),
            feedback: null
        }];

        newAssistantInteraction.nodes = {
            visited: returnVisitedNodes(payload.assistant.output.nodes_visited_details),
            count: payload.assistant.context.system.dialog_turn_counter
        };

        let assistantInteraction = await newAssistantInteraction.save();

        return assistantInteraction
    } catch (err) {
        console.log(err);
    }
}

/* ---------- updateExistingConversation ----------------- 
Update a existing assistant iteration document on the 
database, finded by its ID
------------------------------------------------------- */
async function updateExistingConversation(payload) {
    try {
        let updateAssistantInteraction = Assistant(payload.schema);

        let assistantInteraction = await updateAssistantInteraction.findByIdAndUpdate(payload._id, {
            $push: {
                conversation: {
                    intent: payload.updatedConversation.intents[0] ? payload.updatedConversation.intents[0].intent : [],
                    entity: payload.updatedConversation.entities,
                    input: payload.updatedConversation.input.text,
                    output: payload.updatedConversation.output.text.join(' '),
                    feedback: null,
                    unanswered: payload.updatedConversation.context.unanswered
                },
                'nodes.visited': {
                    $each: returnVisitedNodes(payload.updatedConversation.output.nodes_visited_details)
                }
            },
            $inc: {
                'nodes.count': payload.updatedConversation.output.nodes_visited.length,
                iterationCount: 1,
            }
        }, { new: true });

        return assistantInteraction;
    } catch (err) {
        console.log(err);
    }
}

/* -------------- returnVisitedNodes ------------------- 
Auxiliary function to assign to each visited node its 
actual title
------------------------------------------------------- */
function returnVisitedNodes(payload) {
    var nodesVisited = payload.map(current => {
        return current.title
    });

    return nodesVisited
}

/* --------------- registerFeedback --------------------
Updates a conversation iteration w/ its respective 
feedback and comment.
------------------------------------------------------- */
function registerFeedback(payload) {
    return new Promise(async function(resolve, reject) {
        try {
            var number = parseInt(payload.iterationCount)
            var position = 'conversation.' + number + '.feedback'
            let model = Assistant(payload.schema);
            let assistantInteraction = await model.update({ _id: payload._id }, {
                $set: {
                    [position]: {
                        value: payload.feedback,
                        comment: payload.comment
                    }
                }
            }, { new: true });

            return resolve(assistantInteraction)
        } catch (err) {
            reject('Erro: ' + err)
        }
    });
}


module.exports = {
    registerNewConversation: registerNewConversation,
    updateExistingConversation: updateExistingConversation,
    registerFeedback: registerFeedback
}