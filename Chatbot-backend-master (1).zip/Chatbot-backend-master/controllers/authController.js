var User = require('../models/user')
var bCrypt = require('bcrypt-nodejs')


/* ------------------ loginUser ----------------------- 
Verify if a given user and pass are valid and return 
the result, allowing or not the successfully login
------------------------------------------------------- */
let loginUser = function (user, password) {
    return new Promise(async function (resolve, reject) {
        try {
            let usuario = await User.findOne({
                user: user
            })

            if (!usuario) return resolve(['Usuário não cadastrado', false, null])

            if (!isValidPassword(usuario, password)) {
                return resolve(['Senha incorreta', false, null])
            }

            resolve(['Senha correta', true, {
                _id: usuario._id,
                name: usuario.name,
                user: usuario.user,
                profile: usuario.profile
            }])

        } catch (err) {
            reject('Erro no login do usuário: ' + err)
        }
    })
}

/* -------------- isValidPassword ----------------------
Validates a given password, using bCrypt
------------------------------------------------------- */
var isValidPassword = function (usuario, password) {
    return bCrypt.compareSync(password, usuario.password);
}

module.exports = {
    loginUser: loginUser
}
