const moment = require('moment');

// Connector responsible for managing the chat application content
var assistantConnector = require("../connectors/assistantConnector");

// Controller responsible for managing the persistence of the chat  application content
var assistantController = require("../controllers/mongoController");

/*-------------- sendInputMessage ---------------
Receives the conversation object from the chat 
application and proceeds to send it to the watson 
assistant module
-------------------------------------------------*/
async function sendInputMessage(message) {
    try {
        /* grabs the conversation data from the payload and configures a watson assistant input object */
        var assistantPayload = {
            input: message.assistant.input,
            context: message.assistant.context ? message.assistant.context : null,
            language: message.assistant.language
        }

        console.log('ASSISTANT PAYLOAD: ');
        console.log(assistantPayload);

        var assistantResponse = await assistantConnector.sendMessageToAssistant(assistantPayload);

        const schema = (assistantPayload.language === 'pt-br') ? process.env.ASSISTANT_SCHEMA : process.env.ASSISTANT_SCHEMA_SPA;

        console.log('MONGODB SCHEMA: ' + schema);

        if (assistantPayload.input == '' && !assistantPayload._id) {
            console.log('NEW');
            var iterationDocument = await assistantController.registerNewConversation({
                conversationID: "",
                startedTime: moment().format(),
                email: message.assistant.context.email,
                assistant: assistantResponse,
                schema: schema
            });
            console.log('CREATE DOCUMENT: ' + iterationDocument._id);
        } else {
            console.log('UPDATE DOCUMENT: ' + message._id);
            var iterationDocument = await assistantController.updateExistingConversation({
                _id: message._id,
                iterationTime: moment().format(),
                updatedConversation: assistantResponse,
                schema: schema
            });
            console.log('UPDATE DOCUMENT: ' + iterationDocument._id);
        }

        returnResponse = {
            iterationCount: iterationDocument.iterationCount,
            iterationDocument: {
                _id: iterationDocument._id,
                input: assistantResponse.input.text,
                output: assistantResponse.output.text
            },
            assistantContext: assistantResponse.context
        }

        return (returnResponse)
    } catch (err) {
        throw new Error(err)
    }
}


module.exports = {
    sendInputMessage: sendInputMessage
}