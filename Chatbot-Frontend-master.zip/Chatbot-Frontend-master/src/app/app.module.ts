import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule, IonicPageModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpClient } from '@angular/common/http';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { MyApp } from './app.component';
import { ChatPage } from '../pages/chat/chat';
import { LoginPage } from '../pages/login/login';

import { BackendService } from '../services/backend.service';
import { AuthService } from '../services/auth.service';

import { HttpClientModule } from '@angular/common/http';
import { TooltipsModule } from 'ionic-tooltips';

@NgModule({
    declarations: [
        MyApp,
        ChatPage,
        LoginPage
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        }),
        IonicModule.forRoot(MyApp),
        IonicPageModule.forChild(LoginPage),
        TooltipsModule.forRoot()
    ],
    bootstrap: [IonicApp],
    entryComponents: [
        MyApp,
        ChatPage,
        LoginPage
    ],
    providers: [
        AuthService,
        BackendService,
        StatusBar,
        SplashScreen,
        { provide: ErrorHandler, useClass: IonicErrorHandler }
    ]
})
export class AppModule {
    constructor(translate: TranslateService) {
        translate.addLangs(['pt-br', 'es-es']);
        translate.use(localStorage.getItem('languageSelected') || 'pt-br');
    }
}

export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http);
}