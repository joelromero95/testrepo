import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable()
export class AuthService {

    url = 'https://mvpjj-chat-backend.mybluemix.net';
    
    constructor(private http: HttpClient) {
    }

    login() {
        return this.http.get(this.url + '/auth/login');
    }
}