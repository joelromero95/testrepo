import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class BackendService {

    url = 'https://mvpjj-chat-backend.mybluemix.net';
    constructor(private http: HttpClient) {
    }

    startConversation(email, language) {
        return this.http.post(this.url + '/assistant', {
            assistant: { input: '', context: { email: email }, language: language }
        });
    }

    sendMessage(msgInput) {
        return this.http.post(this.url + '/assistant', msgInput);
    }

    sendFeedback(feedback) {
        return this.http.post(this.url + '/assistant/feedback', feedback);
    }
}