import { Component, ElementRef, ViewChild } from '@angular/core';
import { BackendService } from '../../services/backend.service';
import { NavController, NavParams } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'page-chat',
    templateUrl: 'chat.html',
})
export class ChatPage {
    actualMessage: any;
    isTyping: boolean;
    showScrollButton: boolean;
    actualDate: Date;
    showFeedbackResponse: boolean;
    assistantContext: any;
    possibleResponses: any[];
    isFeedbackCommentary: any;
    iterationCount: any;
    placeholder: any;
    _id: any;
    @ViewChild('chatArea') elChatArea: ElementRef;

    messages = [];

    constructor(private backend: BackendService, public navCtrl: NavController, public navParams: NavParams, public translate: TranslateService) {
        this.placeholder = 'placeholderMessage';
        this.actualMessage = '';
        this.actualDate = new Date();
        this.translate.use(localStorage.getItem('languageSelected'));
    }

    ngOnInit() {
        this.isTyping = true;
        this.createScrollListener();
        setTimeout(() => this.startConversation(), 1000);
    }

    /*Send the first message, start the chat*/
    startConversation() {
        const email = localStorage.getItem('userEmail');
        this.backend.startConversation(email, localStorage.getItem('languageSelected')).subscribe(
            (res: any) => {
                this.isTyping = true;
                this.addBotResponse(res);
            }
        );
    }

    /*Get every bot message and add a timer for each to appear*/
    addBotResponse(resp) {
        this.assistantContext = resp.data.assistantContext;
        this._id = resp.data.iterationDocument._id;
        this.iterationCount = resp.data.iterationCount;
        let msgs = resp.data.iterationDocument.output;

        //For each bot message, add the message in messages array after 2 seconds
        msgs.forEach((msg, index) => {
            setTimeout(() => {
                let botMsg = { user: false, text: msg, date: new Date(), isTyping: true };
                this.messages.push(
                    botMsg
                );
                this.setScrollTiming(10);
                setTimeout(() => {
                    botMsg.isTyping = false;
                    this.setScrollTiming(10);
                    this.isTyping = false;

                    //Add feedback buttons after the last message
                    if (index === msgs.length - 1 && (this.assistantContext.feedback || this.assistantContext.Feedback)) {
                        this.showFeedbackButtons(this.assistantContext.feedback || this.assistantContext.Feedback);
                    }
                }, 1000)
            }, 1600 * (index + 1));

            if (msgs.length === 0) {
                this.isTyping = false;
            }
        });
    }

    /*Send a bot message after user's feedback*/
    addBotFeedbackResponse(msg) {
        let botMsg = { user: false, text: msg, date: new Date(), isTyping: true };
        this.messages.push(botMsg);
        this.setScrollTiming(10);
        setTimeout(() => {
            this.setScrollTiming(10);
            botMsg.isTyping = false;
        }, 1000);
    }

    /* Create a scroll listener to goDown button appear */
    createScrollListener() {
        let chatArea = document.getElementById('chatArea');
        chatArea.addEventListener('scroll', () => {
            const actualScroll = this.elChatArea.nativeElement.scrollTop;
            const scrollHeight = this.elChatArea.nativeElement.scrollHeight - this.elChatArea.nativeElement.clientHeight;
            const scrollPrctg = actualScroll / scrollHeight;
            if (scrollPrctg < 0.8) {
                this.showScrollButton = true;
            } else if (scrollPrctg !== 1) {
                this.showScrollButton = false;
            }

        });
    }

    /*Send a message or feedback to assistant */
    sendMessage() {
        this.showFeedbackResponse = false;
        /*send feedback commentary*/
        if (this.isFeedbackCommentary) {
            let feedback = { _id: this._id, iterationCount: this.iterationCount, feedback: false, comment: this.actualMessage };
            this.backend.sendFeedback(feedback).subscribe(() => {
                this.isFeedbackCommentary = false;
                this.placeholder = 'placeholderMessage';
                const msg = 'feedback1';
                this.addBotFeedbackResponse(msg);
                this.actualMessage = '';
            });
        }
        /*send message*/
        else {
            this.messages.push({ user: true, text: this.actualMessage, date: new Date() });
            this.setScrollTiming(500);
            this.isTyping = true;
            this.assistantContext.feedback = null;
            this.assistantContext.unanswered = null;

            let msgInput = { _id: this._id, assistant: { input: this.actualMessage, context: this.assistantContext, language: this.translate.currentLang } };
            this.backend.sendMessage(msgInput).subscribe((res: any) => {
                this.addBotResponse(res);
            });
            this.actualMessage = '';
        }
    }

    /*Check if feedback is positive or negative*/
    setFeedbackValue(value) {
        if (value.toUpperCase() !== 'SIM' && value.toUpperCase() !== 'SI') {
            this.isFeedbackCommentary = true;
            this.placeholder = 'placeholderFeedback';
            const msg = 'feedback3';
            this.addBotFeedbackResponse(msg);
        } else if (value.toUpperCase() === 'SIM' || value.toUpperCase() === 'SI') {
            let feedback = { _id: this._id, iterationCount: this.iterationCount, feedback: true, comment: '', language: this.translate.currentLang };
            const msg = 'feedback2';
            this.backend.sendFeedback(feedback).subscribe(() => { this.addBotFeedbackResponse(msg); });
        }
        this.showFeedbackResponse = false;
    }

    /*Set a timer to call scrollToBottom function and hide goDown button*/
    setScrollTiming(timer) {
        setTimeout(() => {
            this.scrollToBottom();
            this.showScrollButton = false;
        }, timer)
    }

    /*Scroll chat to bottom */
    scrollToBottom(): void {
        try {
            this.elChatArea.nativeElement.scrollTop = this.elChatArea.nativeElement.scrollHeight;
        } catch (err) {
        }

    }

    /*Check if user pressed Enter Key */
    isEnterKey(key) {
        if (key === 'Enter') {
            this.sendMessage();
        }
    }

    /*Change the chat to feedback mode*/
    showFeedbackButtons(options) {
        this.possibleResponses = options;
        this.showFeedbackResponse = true;
    }

    /*Logout from chat and clean session*/
    logout() {
        localStorage.clear();
        this.navCtrl.pop();
    }
}
