import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Select } from 'ionic-angular';
import { ChatPage } from '../chat/chat';
import { AuthService } from '../../services/auth.service';
import { TranslateService } from '@ngx-translate/core';
import { ToastController } from 'ionic-angular';
import * as CryptoJS from 'crypto-js';

@Component({
    selector: 'page-login',
    templateUrl: 'login.html',
})
export class LoginPage {

    email: any;
    password: any;
    languageSelected: string;
    setWarningMessage = false;
    @ViewChild('languageView') languageView: Select;

    constructor(private authService: AuthService, public navCtrl: NavController, public navParams: NavParams, public toastCtrl: ToastController, public translate: TranslateService) {
        const isLogged = localStorage.getItem('userLoggedInChat');

        if (isLogged === 'true') {
            this.navCtrl.push(ChatPage);
        } else {
            this.authentication();
        }

    }

    login() {
        if (this.languageSelected) {
            localStorage.setItem('languageSelected', this.languageSelected);
            this.translate.use(this.languageSelected);
            this.languageView.setValue('');
            this.authService.login().subscribe((res: any) => {
                window.location.href = res.redirect;
            });

        } else {
            this.setWarningMessage = true;
        }
    }

    isEnterKey(key) {
        if (key === 'Enter') {
            this.login();
        }
    }

    validLanguage() {
        this.setWarningMessage = false;
    }

    authentication() {
        const url = new URL(window.location.href);
        let params = decodeURIComponent(url.searchParams.get("params"));

        if (params !== 'null') {
            params = CryptoJS.AES.decrypt(params, 'abcd1234').toString(CryptoJS.enc.Utf8);
            params = JSON.parse(params);

            if (params['auth']) {
                localStorage.setItem('userLoggedInChat', 'true');
                localStorage.setItem('userEmail', params['email']);
                this.languageSelected = localStorage.getItem('languageSelected');
                this.translate.use(this.languageSelected);
                setTimeout(() => window.location.href = window.location.origin, 1000);
            } else {
                const toast = this.toastCtrl.create({
                    message: 'Invalid user or password',
                    duration: 3000
                });
                toast.present();
            }
        } else {
            localStorage.setItem('userLoggedInChat', 'false');
        }
    }
}
