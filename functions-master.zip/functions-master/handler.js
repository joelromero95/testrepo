'use strict';

var jsforce = require('jsforce');

function hello(params) {
  const name = params.name || 'World';
  return { payload: `Hello, ${name}!` };
}

exports.hello = hello;


function sendRequestSalesforce(params) {
  return new Promise(function (resolve, reject) {
    try {
      //recognized babel code
      var babel_code = params.babelCode

      var query = "SELECT Babel_Procedure__r.Babel_code__c, Material__r.ProductCode, System_Name__c \
          FROM Babel_Material_Procedure__c WHERE Babel_Procedure__r.Country__c='Brazil' \
          AND Type__c='Mandatory' AND Babel_procedure__r.Babel_Code__c='" + babel_code + "'"

      var conn = new jsforce.Connection();

      conn.login('interfaces@jnj.com', 'sfdcjnj2013', function (err, res) {
        if (err) {
          return console.error(err)
        }
        conn.query(query, function (err, res) {
          if (err) {
            return console.error(err)
          }

          var str1 = ""// = 'O Babel em questão é composto pelos seguintes kits mandatórios:'

          res['records'].forEach(function (row) {
            str1 = str1 + row['Material__r']['ProductCode'] + ' ' + row['System_Name__c'] + ', '
          })

          //str1 must be answered to the user   
          resolve({response:str1});
        })
      })
    }
    catch (err) {
      console.log(err)
      reject({error:err})
    }
  })
}

exports.sendRequestSalesforce = sendRequestSalesforce;